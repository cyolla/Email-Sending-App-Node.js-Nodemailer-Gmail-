// index.js
// Email Sending App using Node.js, Nodemailer, Gmail

const nodemailer = require("nodemailer");

// Replace with your Gmail and App Password
const EMAIL_USER = "your_email@gmail.com";
const EMAIL_PASS = "your_app_password";

// Create transporter object
let transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: EMAIL_USER,
    pass: EMAIL_PASS,
  },
});

// Email options
let mailOptions = {
  from: EMAIL_USER,
  to: "recipient@example.com", // multiple: "a@example.com, b@example.com"
  subject: "Test Email from Node.js App 🚀",
  text: "Hello! This is a test email sent using Node.js, Nodemailer, and Gmail SMTP.",
  html: "<h2>Hello!</h2><p>This is a <b>test email</b> sent using <i>Node.js + Nodemailer + Gmail</i> 🚀</p>",
  attachments: [
    {
      filename: "sample.txt",
      content: "This is an attached text file",
    },
  ],
};

// Send email
transporter.sendMail(mailOptions, (error, info) => {
  if (error) {
    return console.log("❌ Error:", error);
  }
  console.log("✅ Email sent successfully:", info.response);
});
